    ____  _________   ___________
   / __ )/ ____/   | / ___/_  __/
  / __  / __/ / /| | \__ \ / /   
 / /_/ / /___/ ___ |___/ // /    
/_____/_____/_/  |_/____//_/   
Beast is comfortable Ralph API client.

How to usage in Windows:
1. Configure config file:
    username - paste ralph login username
    api_keu - paste api key generation with admin panel
    url - paste url ralph instance
    version - is a version api, actually is "v0.9" dont change this line
2. Open command line in folder where is Beast and put best.exe and press enter.
